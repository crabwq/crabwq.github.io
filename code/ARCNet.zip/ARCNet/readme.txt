This code is ONLY released for academic use. Please do not further distribute the code(including the download link), or put any part of the code on the public website. Please kindly cite our paper if you use our code in your research. Thanks and hope you will benefit from our work. 

Citation:
Q. Wang, S. Liu, J. Chanussot, and X. Li, ��Scene Classification with Recurrent Attention of VHR Remote Sensing Images,�� IEEE Transactions on Geoscience and Remote Sensing (T-GRS), vol. 57, no. 2, pp. 1155-1167, 2019.

Copyright (c) 2019, Center for OPTical IMagery Analysis and Learning (OPTIMAL), Northwestern Polytechnical University
All rights reserved. 
