This is the code to learn the optimal graph for clustering.

If you want to use this code, please cite the following paper.

Mulin Chen, Qi Wang, Xuelong Li, "Adaptive Projected Matrix Factorization method for data clustering," Neurocomputing, vol. 306, pp. 182-188, 2018.

For any question, please contact Mulin Chen <chenmulin001@gmail.com>

Copyright (c) by Mulin Chen, Qi Wang, and Xuelong Li.
