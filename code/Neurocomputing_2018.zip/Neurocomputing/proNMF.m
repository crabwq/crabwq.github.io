function [W,predY,objset] = proNMF(X,c,feature_dim,alpha,lambda,rho,mu,initialG)
%%%%%%%%%%%%%%%%%%
%%%%%%% Input: X,c,alpha,feature_dim,lambda,rho,mu,initialG
%%%%%%% Output: objset, predY
%%%%%%%%%%%%%%%%%%

num = size(X,2);
dim = size(X,1);

X0 = X'; % normalize X
mX0 = mean(X0);
X1 = X0 - ones(num,1)*mX0;
scal = 1./sqrt(sum(X1.*X1)+eps);
scalMat = sparse(diag(scal));
X = X1*scalMat;
X = X';

% initialize s
s = constructW_PKN(X, 5, 0); % this function can be found in the homepage of Feiping Nie
% initialize W
s0 = (s+s')/2;
D0 = diag(sum(s0));
L0 = D0-s0;
W = InterationW(L0,X,1e+3,dim,feature_dim);
W0 = W;


% initialize F and Z
G=initialG;
F = W'*X*G;
Z = G;

Niter = 30;
Lambda1 = zeros(feature_dim,num);
Lambda2 = zeros(size(G));
E = Lambda1;
obj = 0;

for iter = 1:Niter

    
    M = W'*X-F*G'+Lambda1/mu;
    obj1 = norm21(E) + mu*0.5*norm(E-M,'fro')*norm(E-M,'fro');
    for i = 1:size(E,2)
        if norm(M(:,i),2)<1/mu
            E(:,i) = 0;
        else
            E(:,i) = (1-1/(mu*norm(M(:,i),2)))*M(:,i);
        end
    end


    %% update F
    H = W'*X-E+Lambda1/mu;
    F = H*G;

    
    %% update Z
    s1 = (s+s')/2;
    D1 = diag(sum(s1));
    L1 = D1-s1;
    l = G-Lambda2/mu-2*lambda*L1*G/mu;
    Z = max(l,0);
    
    %% update G
    
    K = (W'*X-E+Lambda1/mu)'*F+Z-2*lambda*L1*Z/mu+Lambda2/mu;
    [U,~,V] = svd(K,'econ');
    G = U*V';
  
    
   %% update s
    dist = L2_distance_1(W'*X,W'*X); dist = dist - diag(diag(dist)); % this function can be found in the homepage of Feiping Nie
    dist2 = L2_distance_1(G',Z')*lambda/alpha; dist2 = dist2 - diag(diag(dist2));
    
    for i = 1:size(s,1)
        v = dist(i,:);
        u = dist2(i,:);
        idx = [1:num];
        v(i) = []; u(i) = []; idx(i) = [];
        
        [temp,~] = EProjSimplexdiag(-u,v); % this function can be found in the homepage of Feiping Nie
        s(i,idx) = temp;
        s(i,i) = 0;
    end

    
    %% update W    
    temp = s.^2;
    s2 = (temp+temp')/2;
    D_S_ = spdiags(sum(s2,2),0,num,num);
    L_S_ = D_S_-s2;
    S_ = X*L_S_*X'; S_ = (S_+S_')/2;
    Q = F*G'+E-Lambda1/mu;
    B = X*Q'*0.25*mu/alpha;

    
    W = GPI(S_,B,1,W);   

    
    %% update alm
    Lambda1 = Lambda1 + mu*(E-W'*X+F*G');
    Lambda2 = Lambda2 + mu*(Z-G);
    mu = rho*mu;
    

end

[~,predY] = max(Z,[],2);

